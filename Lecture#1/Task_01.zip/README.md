# Class Tasks

This repository contains materials for Lecture #1 including:
- HTML content files
- Documentation
- Supporting images

These files are part of classroom assignments and exercises. 